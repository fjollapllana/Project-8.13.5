public class Projekt{
   private double rreshtat;
   private int shtyllat;
   private String [][] array1;
   private int [] array2;  
   public String [][] Transposition(int[] a1,String [] a2){
      array2=a1;
      double r=((a1.length)+(a2.length))/(a1.length);
      rreshtat=Math.ceil(r);
      shtyllat=a1.length;
      array1=new String[(int)rreshtat][shtyllat];
      
      int k=0;
      for(int i=0;i<rreshtat;i++){
         for(int j=0;j<shtyllat;j++){
            if(i==0){
               array1[0][j]=""+a1[j];
            }
            else {
               array1[i][j]=a2[k];
               k++;
            }
         }
      }
      return array1;     
   } 
   public String [][] Rreshtimi(){
   
      int z=0;
      while(z<rreshtat){
      
         for(int i=0;i<array2.length-1;i++){
            int j=i+1;
            boolean b=array2[i]>array2[j];
            if(b){
               for(int k=0;k<array1.length;k++){
                  String numer=array1[k][i];
                  array1[k][i]=array1[k][i+1];
                  array1[k][i+1]=numer;
               }
            }}
         z++;}
      return array1;
   }}