import javax.swing.*;
import java.awt.*;
public class ProjektWriter extends JPanel
{
   private int width=500;
   private int height=300;
   private int x=150;
   private int y=50;
   private Projekt transposition;
   private String [][] array;
   
   public ProjektWriter(String [][]a)
   { array=a;
      JFrame frame=new JFrame();    
      frame.setSize(width,height);
      frame.setVisible(true);
      frame.setResizable(false);   
      frame.getContentPane().add(this);  
   }
   public void paintComponent(Graphics g){
      g.setColor(Color.white);
      g.fillRect(0,0,width,height);
      g.setColor(Color.black);
      for(int i=0;i<array.length;i++){
         for(int j=0;j<array[i].length;j++){
            g.drawString(array[i][j],x,y);
            x+=10;       
         }
         y+=15;   
         x=150;
      }
   }
}