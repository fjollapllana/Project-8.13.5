import javax.swing.*;
import java.awt.*;
public class Controller{
   private ProjektReader reader;
   private Projekt transposition;
   String [][] finalArray;
   String [][] array3;
   public Controller(ProjektReader r,Projekt t){
      reader=r;
      transposition=t;
   }
   public void theTransposition(){
      reader.Numrat();
      reader.Karakteret();
      int [] array1=reader.Vargu_i_celesit();
      String [] array2=reader.Vargu_i_mesazhit();
      String [][] array3=transposition.Transposition(array1,array2);
      String [][] finalArray=transposition.Rreshtimi();
      
      ProjektWriter writer=new ProjektWriter(finalArray);
   }
   public static void main(String [] args){
      Projekt t=new Projekt();
      ProjektReader r=new ProjektReader();
      Controller c=new Controller(r,t);
      c.theTransposition();
      
   }}
