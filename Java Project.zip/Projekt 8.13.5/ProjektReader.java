import javax.swing.*;
public class ProjektReader{
   private String fjalia_1;
   private String fjalia_2;
   public ProjektReader(){
      fjalia_1="";
      fjalia_2="";
   }
   private boolean checkMessage(String mesazhi) {
      return mesazhi == null || mesazhi=="" ||mesazhi.trim().length() < 3;
   } 
   public String Numrat(){
      fjalia_1=JOptionPane.showInputDialog("Shkruani celesin hyres:");
      if(checkMessage(fjalia_1)){
         JOptionPane.showMessageDialog(null,"Celes jo valid.");
         System.exit(0);
      }
      return fjalia_1;
   }
   public String Karakteret(){
     
      fjalia_2=JOptionPane.showInputDialog("Shkruani mesazhin:");
      if(checkMessage(fjalia_2)){
         JOptionPane.showMessageDialog(null,"Mesazh jo valid.");
         System.exit(0);
      }
      fjalia_2=fjalia_2.toLowerCase().trim();
      return fjalia_2;
   }
   public int[] Vargu_i_celesit(){
      int count=1;
      int number;
      int gjatesia=fjalia_1.length();
      int[] array
      ;
      for(int i=0;i<fjalia_1.length();i++){
         if(fjalia_1.charAt(i)==' '){
            gjatesia=gjatesia-1;
         }
      }
      array=new int[gjatesia];
      for(int i=0;i<gjatesia;i++)
      { number=new Integer(fjalia_1.substring(i,i+1)).intValue();
         array[i]=number;  
      }
      return array;
   }
   public String [] Vargu_i_mesazhit(){
      int count=1;
      String result="";
      String [] array;
      int gjatesia2=fjalia_2.length();
      for(int i=0;i<gjatesia2;i++){
         if(fjalia_2.charAt(i)==' ')
         {gjatesia2=gjatesia2-count;}
      }
      array=new String[gjatesia2];
      for(int i=0;i<gjatesia2;i++){
         result=(fjalia_2.substring(i,i+1));
         array[i]=result;
      }
      return array;
   }
}